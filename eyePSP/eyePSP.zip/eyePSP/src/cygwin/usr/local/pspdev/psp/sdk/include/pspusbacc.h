#ifndef __PSPUSBACC_H__
#define __PSPUSBACC_H__

#ifdef __cplusplus
extern "C" {
#endif

#define PSP_USBACC_DRIVERNAME	"USBAccBaseDriver"

#ifdef __cplusplus
}
#endif

#endif 



