#ifndef _LOGO
#define _LOGO

unsigned char logo[2635];

#endif
